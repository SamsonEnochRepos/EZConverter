# EZConverter

A cross-platform universal file converter: web, desktop (Windows/macOS/Linux via Electron) and mobile (iOS/Android via Expo), all on one
capability-driven conversion core with real engines, safe batch processing, verified outputs and an explicit local/remote privacy model.

> **Status:** a working, tested foundation, not a finished product. See [docs/STATUS.md](docs/STATUS.md) for exactly what has and has not been
> verified (for example: Linux desktop and Chromium were exercised; Windows, macOS, and physical iOS/Android devices were not).

## What makes it different

* **Real conversions, honestly scoped.** 321 direct conversion capabilities across documents, spreadsheets, presentations, images, audio, video,
  archives and structured data. A capability is advertised only after it has converted a real input file with the real engine and the output
  passed independent checks ([format matrix](docs/format-matrix/README.md)). Unsupported requests get an explanation, never a fake result.
* **Identified by content, not by name.** Format detection reads bytes (magic numbers, container structure, codec probes); extensions are hints.
* **Batch is first-class.** Mixed files, independent per-file outcomes, bounded concurrency, cancel, retry, resume after restart, collision-safe
  output names, and a ZIP with a `manifest.json` that lists failures separately from outputs.
* **Verified before "done".** A job succeeds only after format-specific validation (decode, parse, stream probe, page/row/member counts,
  duration/dimension checks). Failed or partial output is never exposed.
* **Private by construction.** `LOCAL_ONLY` never uploads (enforced in the client router *and* by the server, which refuses before reading a byte).
  Uploading to a remote converter needs explicit consent. Workers run sandboxed: scrubbed environment, resource limits, empty network namespace.

## Repository layout

```
backend/ezconverter/   Python conversion core + FastAPI (domain, detection, registry, planner, engines, validation, workers, orchestration, api)
packages/contracts/    TypeScript types generated from the backend's OpenAPI document
packages/api-client/   typed client shared by every app
packages/shared-domain/ router (local/remote policy), batch state + controller, presets, formatting
packages/ui/           React components (web + desktop renderer)
apps/web/              Vite + React + Tailwind app
apps/desktop/          Electron shell (hardened renderer, loopback Python sidecar)
apps/mobile/           Expo / React Native app
tests/                 unit, integration, security, conformance (real engines), fixtures generator
docs/                  architecture, api, format-matrix, security, operations, STATUS
deployment/            container draft, configuration, observability notes
scripts/               setup, verify, matrix + license generators, contract checks
```

## Quick start

```bash
scripts/setup.sh                       # venv + pnpm install + checks which external engines are present
cp .env.example .env                   # then edit; for local use: EZ_AUTH_MODE=none is acceptable on loopback only
.venv/bin/python -m ezconverter serve  # API on http://127.0.0.1:8787  (docs at /docs)
pnpm --filter @ezconverter/web dev     # web app on http://localhost:5173 (add the origin to EZ_ALLOWED_ORIGINS)
pnpm --filter @ezconverter/desktop start   # Electron app; it launches and owns its own converter sidecar
pnpm --filter @ezconverter/mobile start    # Expo dev server (needs a device/emulator; phones convert via a remote runtime)
```

External engines the backend drives (install what you want to offer; missing ones simply disable their capabilities, listed in `/v1/capabilities?include_unavailable=true`):
FFmpeg/ffprobe, LibreOffice, Pandoc, Poppler (`pdftoppm`, `pdfinfo`), util-linux (`prlimit`, `unshare`). Python libraries: Pillow, pypdf, PyYAML, defusedxml, optional py7zr.

## Using it

1. Add files (drop, pick, or share). Each is identified from its bytes and shown with its detected format.
2. Choose a target. Only conversions that exist *for that file on your configured converters* are offered. Settings are generated from the capability's declared options.
3. Review the notes: fidelity class (exact / lossless / lossy / layout may change / content transformed), per-step warnings, where it will run.
4. Convert. Per-file progress is real (or explicitly "in progress" when an engine cannot measure it). Cancel any time.
5. Download files individually or all as a ZIP. Delete results immediately, or let retention remove them.

## Verification

`scripts/verify.sh` runs everything that can run on the machine and prints a PASS/FAIL/SKIP summary (skips name the missing capability).
Individual entry points: `pytest tests`, `pnpm -r test`, `pnpm e2e`, and the per-app e2e commands in each `package.json`.

## Documentation

* [Architecture and decisions](docs/architecture/README.md)
* [API](docs/api/README.md) · [openapi.json](docs/api/openapi.json)
* [Format matrix](docs/format-matrix/README.md) · [capability manifest](docs/format-matrix/capabilities.json)
* [Security model](docs/security/README.md) · [License inventory](docs/security/license-inventory.md)
* [Operations](docs/operations/README.md)
* [Implementation status, risks and release blockers](docs/STATUS.md)

import { type ReactNode, useEffect, useRef, useState } from "react";
import { Animated, Easing, FlatList, Modal, Pressable, StyleSheet, Switch, Text, TextInput, View, type ViewStyle } from "react-native";
import type { OptionOut } from "@ezconverter/contracts";
import { type Theme } from "../theme";
import { useApp } from "../state";

export const MIN_TOUCH = 48;

export function useT(): Theme { return useApp().theme; }

export function Txt({ children, size = 15, weight = "400", color, style, ...rest }: { children: ReactNode; size?: number; weight?: "400" | "600" | "700"; color?: string; style?: object } & Omit<React.ComponentProps<typeof Text>, "style">) {
  const t = useT();
  const scale = useApp().settings.largeText ? 1.2 : 1;
  return <Text {...rest} style={[{ fontSize: size * scale, fontWeight: weight, color: color ?? t.text }, style]}>{children}</Text>;
}

export function Card({ children, style, testID }: { children: ReactNode; style?: ViewStyle; testID?: string }) {
  const t = useT();
  return <View testID={testID} style={[{ backgroundColor: t.surface, borderColor: t.line, borderWidth: StyleSheet.hairlineWidth * 2, borderRadius: 16, padding: 14 }, style]}>{children}</View>;
}

export function Btn({ title, onPress, variant = "secondary", disabled, testID, accessibilityLabel }: { title: string; onPress: () => void; variant?: "primary" | "secondary" | "danger" | "ghost"; disabled?: boolean; testID?: string; accessibilityLabel?: string }) {
  const t = useT();
  const bg = { primary: t.accent, secondary: t.surface2, danger: t.badSoft, ghost: "transparent" }[variant];
  const fg = { primary: t.accentText, secondary: t.text, danger: t.bad, ghost: t.muted }[variant];
  return (
    <Pressable accessibilityRole="button" accessibilityLabel={accessibilityLabel ?? title} accessibilityState={{ disabled: !!disabled }} testID={testID} disabled={disabled} onPress={onPress}
               style={({ pressed }) => ({ minHeight: MIN_TOUCH, minWidth: MIN_TOUCH, paddingHorizontal: 16, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: bg, opacity: disabled ? 0.45 : pressed ? 0.8 : 1 })}>
      <Txt weight="600" color={fg}>{title}</Txt>
    </Pressable>
  );
}

export function Badge({ tone = "neutral", children }: { tone?: "good" | "warn" | "bad" | "info" | "neutral"; children: string }) {
  const t = useT();
  const c = { good: [t.goodSoft, t.good], warn: [t.warnSoft, t.warn], bad: [t.badSoft, t.bad], info: [t.infoSoft, t.info], neutral: [t.surface2, t.muted] }[tone];
  return <View style={{ backgroundColor: c[0], borderRadius: 99, paddingHorizontal: 10, paddingVertical: 3, alignSelf: "flex-start" }}><Txt size={12} weight="600" color={c[1]}>{children}</Txt></View>;
}

export function Notice({ tone = "info", title, children }: { tone?: "info" | "warn" | "bad" | "good"; title?: string; children?: ReactNode }) {
  const t = useT();
  const c = { good: [t.goodSoft, t.good], warn: [t.warnSoft, t.warn], bad: [t.badSoft, t.bad], info: [t.infoSoft, t.info] }[tone];
  return (
    <View accessibilityRole={tone === "bad" ? "alert" : undefined} style={{ backgroundColor: c[0], borderRadius: 12, padding: 12, gap: 2 }}>
      {title && <Txt weight="600" color={c[1]}>{title}</Txt>}
      {children !== undefined && <Txt size={14} color={c[1]}>{children}</Txt>}
    </View>
  );
}

/** value null = indeterminate: shows a moving bar, never an invented percentage. */
export function Progress({ value, label }: { value: number | null; label: string }) {
  const t = useT();
  const reduce = useApp().settings.reduceMotion;
  const x = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (value !== null || reduce) return;
    const loop = Animated.loop(Animated.timing(x, { toValue: 1, duration: 1300, easing: Easing.inOut(Easing.ease), useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [value, reduce, x]);
  const pct = value === null ? undefined : Math.round(Math.max(0, Math.min(1, value)) * 100);
  return (
    <View accessible accessibilityRole="progressbar" accessibilityLabel={label} accessibilityValue={pct === undefined ? { text: "In progress" } : { min: 0, max: 100, now: pct }}
          style={{ height: 8, borderRadius: 99, backgroundColor: t.surface2, overflow: "hidden" }}>
      {pct === undefined
        ? <Animated.View style={{ position: "absolute", top: 0, bottom: 0, width: "40%", borderRadius: 99, backgroundColor: t.accent, transform: [{ translateX: x.interpolate({ inputRange: [0, 1], outputRange: [-120, 320] }) }] }} />
        : <View style={{ height: 8, width: `${pct}%`, borderRadius: 99, backgroundColor: t.accent }} />}
    </View>
  );
}

export interface Choice<T extends string | number> { value: T; label: string; hint?: string; group?: string }

/** Bottom-sheet single choice list. Used for target formats and enum settings. */
export function ChoiceSheet<T extends string | number>({ visible, title, choices, selected, onSelect, onClose }: { visible: boolean; title: string; choices: Choice<T>[]; selected?: T; onSelect: (v: T) => void; onClose: () => void }) {
  const t = useT();
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose} accessibilityViewIsModal>
      <Pressable style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.45)" }} onPress={onClose} accessibilityLabel="Close" />
      <View style={{ maxHeight: "70%", backgroundColor: t.surface, borderTopLeftRadius: 20, borderTopRightRadius: 20, paddingTop: 8 }}>
        <View style={{ padding: 16, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
          <Txt size={17} weight="700">{title}</Txt>
          <Btn title="Close" variant="ghost" onPress={onClose} />
        </View>
        <FlatList data={choices} keyExtractor={(c) => String(c.value)} contentContainerStyle={{ paddingBottom: 24 }}
          renderItem={({ item, index }) => {
            const showGroup = item.group && (index === 0 || choices[index - 1]?.group !== item.group);
            return (
              <View>
                {showGroup && <Txt size={12} weight="700" color={t.muted} style={{ paddingHorizontal: 16, paddingTop: 10, paddingBottom: 4 }}>{item.group!.toUpperCase()}</Txt>}
                <Pressable accessibilityRole="menuitem" accessibilityState={{ selected: item.value === selected }} onPress={() => { onSelect(item.value); onClose(); }}
                           style={{ minHeight: MIN_TOUCH, paddingHorizontal: 16, justifyContent: "center", backgroundColor: item.value === selected ? t.accentSoft : "transparent" }}>
                  <Txt weight={item.value === selected ? "600" : "400"}>{item.label}</Txt>
                  {item.hint && <Txt size={12} color={t.muted}>{item.hint}</Txt>}
                </Pressable>
              </View>
            );
          }} />
      </View>
    </Modal>
  );
}

export function Field({ label, value, onChangeText, secure, placeholder, hint, keyboardType, testID }: { label: string; value: string; onChangeText: (v: string) => void; secure?: boolean; placeholder?: string; hint?: string; keyboardType?: "default" | "numeric" | "url"; testID?: string }) {
  const t = useT();
  return (
    <View style={{ gap: 4 }}>
      <Txt size={13} weight="600" color={t.muted}>{label}</Txt>
      <TextInput testID={testID} accessibilityLabel={label} value={value} onChangeText={onChangeText} secureTextEntry={secure} placeholder={placeholder} placeholderTextColor={t.muted}
                 autoCapitalize="none" autoCorrect={false} keyboardType={keyboardType} style={{ minHeight: MIN_TOUCH, borderWidth: 1, borderColor: t.line, borderRadius: 12, paddingHorizontal: 12, color: t.text, backgroundColor: t.surface }} />
      {hint && <Txt size={12} color={t.muted}>{hint}</Txt>}
    </View>
  );
}

export function Toggle({ label, hint, value, onChange, testID }: { label: string; hint?: string; value: boolean; onChange: (v: boolean) => void; testID?: string }) {
  const t = useT();
  return (
    <View style={{ flexDirection: "row", alignItems: "center", gap: 12, minHeight: MIN_TOUCH }}>
      <View style={{ flex: 1 }}><Txt weight="600">{label}</Txt>{hint && <Txt size={13} color={t.muted}>{hint}</Txt>}</View>
      <Switch testID={testID} accessibilityLabel={label} value={value} onValueChange={onChange} trackColor={{ true: t.accent, false: t.line }} />
    </View>
  );
}

/** Settings editor generated from a capability's declared options (same schema the web UI uses). */
export function OptionsForm({ specs, values, onChange }: { specs: OptionOut[]; values: Record<string, unknown>; onChange: (next: Record<string, unknown>) => void }) {
  const t = useT();
  const [sheet, setSheet] = useState<OptionOut | null>(null);
  const set = (name: string, v: unknown) => onChange({ ...values, [name]: v });
  return (
    <View style={{ gap: 14 }} testID="options-form">
      {specs.map((s) => {
        const v = values[s.name] ?? s.default;
        const label = s.name.replace(/_/g, " ");
        if (s.type === "bool") return <Toggle key={s.name} label={label} hint={s.description} value={Boolean(v)} onChange={(b) => set(s.name, b)} />;
        if (s.type === "enum") return (
          <View key={s.name} style={{ gap: 4 }}>
            <Txt size={13} weight="600" color={t.muted}>{label}</Txt>
            <Btn title={String(v === "\t" ? "Tab" : v)} onPress={() => setSheet(s)} />
            <Txt size={12} color={t.muted}>{s.description}</Txt>
          </View>
        );
        return <Field key={s.name} label={label} value={v === null || v === undefined ? "" : String(v)} keyboardType={s.type === "string" ? "default" : "numeric"}
                      hint={`${s.description}${s.minimum != null && s.maximum != null ? ` (${s.minimum}–${s.maximum})` : ""}`}
                      onChangeText={(txt) => { if (s.type === "string") set(s.name, txt); else if (txt.trim() !== "" && !Number.isNaN(Number(txt))) set(s.name, Number(txt)); }} />;
      })}
      {sheet && <ChoiceSheet visible title={sheet.name.replace(/_/g, " ")} selected={String(values[sheet.name] ?? sheet.default)} onClose={() => setSheet(null)}
                             choices={(sheet.choices ?? []).map((c) => ({ value: String(c), label: c === "\t" ? "Tab" : String(c) }))}
                             onSelect={(val) => set(sheet.name, (sheet.choices ?? []).find((c) => String(c) === val) ?? val)} />}
    </View>
  );
}

import { BUILT_IN_PRESETS, FIDELITY, formatBytes, summarize } from "@ezconverter/shared-domain";
import { useKeepAwake } from "expo-keep-awake";
import { useEffect, useState } from "react";
import { ActivityIndicator, FlatList, ScrollView, View } from "react-native";
import { ItemCard } from "../components/ItemCard";
import { Badge, Btn, Card, ChoiceSheet, Notice, Toggle, Txt, useT } from "../components/ui";
import { pickFiles, saveAndShare } from "../platform";
import { loadHistory, useApp } from "../state";

export function Convert({ goSettings }: { goSettings: () => void }) {
  const { state, controller, catalog, runtimes } = useApp();
  const t = useT();
  const sum = summarize(state);
  const running = state.phase === "running";
  if (running) return <Running />;
  if (state.items.length === 0) return <Home goSettings={goSettings} />;
  if (state.phase === "finished") return <Results />;

  const ready = state.items.filter((i) => i.intake.state === "ready" && !i.duplicateOf);
  const families = new Set(ready.map((i) => catalog.formats.get(i.file?.format ?? "")?.family).filter(Boolean) as string[]);
  const presets = BUILT_IN_PRESETS.filter((p) => families.has(p.family));
  return (
    <View style={{ flex: 1 }}>
      <FlatList data={state.items} keyExtractor={(i) => i.key} contentContainerStyle={{ padding: 16, gap: 12, paddingBottom: 140 }}
        ListHeaderComponent={
          <View style={{ gap: 10 }}>
            <PolicyRow />
            {presets.length > 0 && <PresetRow presets={presets} />}
            {runtimes.length === 0 && <Notice tone="warn" title="No converter set up">Add the address of a converter in Settings. Nothing has been uploaded.</Notice>}
            {state.items.some((i) => i.planError?.code === "remote_consent_required") && (
              <Notice tone="warn" title="Needs a remote converter">Your phone can't convert some of these on its own. Allow uploading in Settings to continue. Nothing has been uploaded.</Notice>
            )}
          </View>
        }
        renderItem={({ item }) => <ItemCard item={item} phase={state.phase} controller={controller} />} />
      <View style={{ position: "absolute", left: 0, right: 0, bottom: 0, padding: 12, gap: 8, backgroundColor: t.surface, borderTopWidth: 1, borderColor: t.line }}>
        <Txt size={13} color={t.muted} testID="start-summary">
          {sum.uploading > 0 ? `Reading ${sum.uploading} file${sum.uploading > 1 ? "s" : ""}…` : `${sum.startable} of ${state.items.length} ready${sum.skipped ? ` · ${sum.skipped} skipped` : ""}`}
        </Txt>
        <View style={{ flexDirection: "row", gap: 8 }}>
          <View style={{ flex: 1 }}><Btn title="Add files" onPress={async () => { const f = await pickFiles(); if (f.length) await controller.addFiles(f); }} /></View>
          <View style={{ flex: 1 }}><Btn testID="start-button" title={`Convert ${sum.startable || ""}`.trim()} variant="primary" disabled={sum.startable === 0 || sum.uploading > 0} onPress={() => void controller.start()} /></View>
        </View>
        <Btn title="Clear all" variant="ghost" onPress={() => void controller.clear()} />
      </View>
    </View>
  );
}

function PolicyRow() {
  const { state, controller } = useApp();
  const [open, setOpen] = useState(false);
  const label = { AUTO: "Automatic", LOCAL_ONLY: "Local only", REMOTE_ALLOWED: "Allow remote" }[state.defaultPolicy];
  return (
    <>
      <Btn testID="policy-button" title={`Processing: ${label}`} onPress={() => setOpen(true)} />
      <ChoiceSheet visible={open} title="Processing" selected={state.defaultPolicy} onClose={() => setOpen(false)} onSelect={(p) => controller.setPolicy("all", p)}
                   choices={[{ value: "AUTO", label: "Automatic", hint: "Use this device when it can; ask before uploading" }, { value: "LOCAL_ONLY", label: "Local only", hint: "Never upload. This phone can't convert on its own, so most conversions will be refused" }, { value: "REMOTE_ALLOWED", label: "Allow remote converters", hint: "Upload to your converter" }]} />
    </>
  );
}

function PresetRow({ presets }: { presets: typeof BUILT_IN_PRESETS }) {
  const { controller, catalog } = useApp();
  const [open, setOpen] = useState(false);
  return (
    <>
      <Btn title="Apply a preset…" onPress={() => setOpen(true)} />
      <ChoiceSheet visible={open} title="Presets" onClose={() => setOpen(false)} choices={presets.map((p) => ({ value: p.id, label: p.name, hint: p.description }))}
                   onSelect={(id) => { const p = presets.find((x) => x.id === id); if (p) controller.applyPreset(p, new Map([...catalog.formats].map(([k, v]) => [k, v.family]))); }} />
    </>
  );
}

function Home({ goSettings }: { goSettings: () => void }) {
  const { controller, catalog, settings, setSettings, runtimes } = useApp();
  const t = useT();
  const [recent, setRecent] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  useEffect(() => { void loadHistory().then((h) => setRecent([...new Set(h.filter((e) => e.state === "SUCCEEDED").map((e) => e.target))].slice(0, 6))); }, []);
  const needsConsent = runtimes.length > 0 && !settings.allowRemote && settings.defaultPolicy === "AUTO";
  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }}>
      <View style={{ gap: 14 }}>
        <View style={{ gap: 6, paddingTop: 8 }}>
          <Txt size={30} weight="700">Convert anything, <Txt size={30} weight="700" color={t.accent}>simply</Txt>.</Txt>
          <Txt color={t.muted}>Pick files from your phone. EZConverter identifies each one by its content and only offers conversions it can really do.</Txt>
        </View>
        {runtimes.length === 0 ? (
          <Notice tone="warn" title="Set up a converter first">This phone sends files to a converter you control. Add its address in Settings.</Notice>
        ) : needsConsent ? (
          <Card style={{ gap: 8 }}>
            <Txt weight="700">Allow uploading?</Txt>
            <Txt size={14} color={t.muted}>Phones can't convert most formats on their own. Files are sent over an encrypted connection to your converter and deleted automatically{catalog.status.health ? ` after ${catalog.status.health.retention_hours} hours` : ""}.</Txt>
            <Toggle testID="allow-remote" label="Allow uploading to my converter" value={settings.allowRemote} onChange={(v) => setSettings({ allowRemote: v })} />
          </Card>
        ) : null}
        <Btn testID="choose-files" title={busy ? "Opening…" : "Choose files"} variant="primary" disabled={busy || runtimes.length === 0}
             onPress={async () => { setBusy(true); try { const f = await pickFiles(); if (f.length) await controller.addFiles(f); } finally { setBusy(false); } }} />
        <Card style={{ gap: 6 }} testID="runtime-status">
          <Txt weight="700">Converter</Txt>
          {catalog.status.state === "checking" && <View style={{ flexDirection: "row", gap: 8 }}><ActivityIndicator /><Txt color={t.muted}>Connecting…</Txt></View>}
          {catalog.status.state === "online" && <Badge tone="good">{`${catalog.status.caps?.capabilities.length ?? 0} verified conversions`}</Badge>}
          {catalog.status.state === "unauthorized" && <Notice tone="warn" title="Access token needed">Enter your token in Settings.</Notice>}
          {catalog.status.state === "offline" && <Notice tone="bad" title="Can't reach the converter">{catalog.status.error ?? "Check the address in Settings."}</Notice>}
          <Btn title="Settings" variant="ghost" onPress={goSettings} />
        </Card>
        {recent.length > 0 && <Card style={{ gap: 6 }}><Txt weight="700">Recently used formats</Txt><View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>{recent.map((r) => <Badge key={r}>{catalog.formats.get(r)?.name ?? r.toUpperCase()}</Badge>)}</View></Card>}
      </View>
    </ScrollView>
  );
}

function Running() {
  const { state, controller } = useApp();
  const t = useT();
  const sum = summarize(state);
  useKeepAwake();     // keep the screen on while converting; the converter keeps working if the OS suspends the app anyway
  return (
    <View style={{ flex: 1 }}>
      <FlatList data={state.items} keyExtractor={(i) => i.key} contentContainerStyle={{ padding: 16, gap: 12, paddingBottom: 130 }} renderItem={({ item }) => <ItemCard item={item} phase={state.phase} controller={controller} />} />
      <View style={{ position: "absolute", left: 0, right: 0, bottom: 0, padding: 12, gap: 8, backgroundColor: t.surface, borderTopWidth: 1, borderColor: t.line }} testID="overall-progress">
        <Txt weight="600">Converting… {sum.indeterminate ? "" : `${Math.round(sum.progress * 100)}%`}</Txt>
        <Txt size={12} color={t.muted}>You can leave the app: conversion continues on the converter and picks up where you left off.</Txt>
        <Btn title="Cancel remaining" variant="danger" onPress={() => void controller.cancel()} />
      </View>
    </View>
  );
}

function Results() {
  const { state, controller } = useApp();
  const t = useT();
  const [busy, setBusy] = useState<string>();
  const [msg, setMsg] = useState<string>();
  const sum = summarize(state);
  const ok = state.items.filter((i) => i.job?.state === "SUCCEEDED");
  const bad = state.items.filter((i) => i.job?.state === "FAILED");
  const other = state.items.filter((i) => !i.job || i.job.state === "CANCELLED");
  const share = async (key: string) => {
    const it = state.items.find((i) => i.key === key); if (!it?.result) return;
    setBusy(key); setMsg(undefined);
    try { const url = await controller.downloadUrl(key); if (url) await saveAndShare(url, it.result.name, it.result.mime); } catch (e) { setMsg((e as Error).message); } finally { setBusy(undefined); }
  };
  const zip = async () => { setBusy("zip"); setMsg(undefined); try { const url = await controller.archiveUrl(0); if (url) await saveAndShare(url, "ezconverter-batch.zip", "application/zip"); } catch (e) { setMsg((e as Error).message); } finally { setBusy(undefined); } };
  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 12 }}>
      <View style={{ gap: 12 }} testID="results">
        <Txt size={22} weight="700" testID="results-summary">{`${sum.succeeded} converted${sum.failed ? `, ${sum.failed} failed` : ""}${sum.cancelled ? `, ${sum.cancelled} cancelled` : ""}${other.length - sum.cancelled > 0 ? `, ${other.length - sum.cancelled} skipped` : ""}`}</Txt>
        <Txt size={13} color={t.muted}>Originals were not changed. Results are kept temporarily and deleted automatically.</Txt>
        {msg && <Notice tone="bad" title="Couldn't save">{msg}</Notice>}
        {ok.length > 1 && <Btn testID="zip-button" title={busy === "zip" ? "Preparing…" : "Share all as ZIP"} variant="primary" disabled={busy === "zip"} onPress={() => void zip()} />}
        {ok.map((i) => (
          <Card key={i.key} style={{ gap: 8 }} testID="result-card">
            <Txt weight="600" testID="result-name">{i.result?.name ?? i.source.name}</Txt>
            <Txt size={12} color={t.muted}>{i.result ? formatBytes(i.result.size) : ""} · from {i.source.name}</Txt>
            <View style={{ flexDirection: "row", gap: 6, flexWrap: "wrap" }}>
              {i.result && <Badge tone={FIDELITY[i.result.fidelity].tone === "good" ? "good" : FIDELITY[i.result.fidelity].tone === "warn" ? "warn" : "info"}>{FIDELITY[i.result.fidelity].label}</Badge>}
              {i.result?.verification.ok && <Badge tone="good">Verified</Badge>}
            </View>
            {(i.job?.warnings ?? []).slice(0, 3).map((w) => <Txt key={w} size={12} color={t.warn}>⚠ {w}</Txt>)}
            <Btn testID="share-button" title={busy === i.key ? "Preparing…" : "Save / Share"} variant="primary" disabled={!i.result || busy === i.key} onPress={() => void share(i.key)} />
          </Card>
        ))}
        {bad.map((i) => (
          <Notice key={i.key} tone="bad" title={`${i.source.name} failed`}>{i.job?.error?.message ?? ""}</Notice>
        ))}
        {bad.some((i) => i.job?.can_retry) && <Btn title="Retry failed" onPress={() => void controller.retryFailed()} />}
        <Btn testID="new-batch" title="Convert more" onPress={() => void controller.clear()} />
        <Btn title="Delete results now" variant="danger" onPress={() => void controller.deleteEverything()} />
      </View>
    </ScrollView>
  );
}

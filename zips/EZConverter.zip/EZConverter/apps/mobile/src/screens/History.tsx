import { STATE_LABEL, formatBytes } from "@ezconverter/shared-domain";
import { useEffect, useState } from "react";
import { FlatList, View } from "react-native";
import { Badge, Btn, Card, Txt, useT } from "../components/ui";
import { type HistoryEntry, loadHistory, saveHistory, useApp } from "../state";

export function History() {
  const t = useT();
  const { catalog } = useApp();
  const [items, setItems] = useState<HistoryEntry[]>([]);
  useEffect(() => { void loadHistory().then(setItems); }, []);
  return (
    <FlatList data={items} keyExtractor={(e) => e.id} contentContainerStyle={{ padding: 16, gap: 10 }}
      ListHeaderComponent={<View style={{ gap: 8, marginBottom: 6 }}><Txt size={22} weight="700">History</Txt><Txt size={13} color={t.muted}>Stored only on this phone. Converted files are deleted from the converter automatically.</Txt>{items.length > 0 && <Btn title="Clear history" variant="danger" onPress={() => { void saveHistory([]); setItems([]); }} />}</View>}
      ListEmptyComponent={<Card><Txt color={t.muted}>Nothing here yet. Finished conversions will be listed.</Txt></Card>}
      renderItem={({ item: e }) => (
        <Card style={{ gap: 4 }}>
          <Txt weight="600" numberOfLines={1}>{e.name}</Txt>
          <Txt size={12} color={t.muted}>{`${e.source.toUpperCase()} → ${catalog.formats.get(e.target)?.name ?? e.target.toUpperCase()} · ${new Date(e.at).toLocaleString()}${e.size ? ` · ${formatBytes(e.size)}` : ""}`}</Txt>
          {e.error && <Txt size={12} color={t.bad}>{e.error}</Txt>}
          <Badge tone={e.state === "SUCCEEDED" ? "good" : e.state === "FAILED" ? "bad" : "neutral"}>{STATE_LABEL[e.state as keyof typeof STATE_LABEL] ?? e.state}</Badge>
        </Card>
      )} />
  );
}

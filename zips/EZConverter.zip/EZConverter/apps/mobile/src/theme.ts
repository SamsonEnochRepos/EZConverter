import { useColorScheme } from "react-native";

export interface Theme {
  bg: string; surface: string; surface2: string; text: string; muted: string; line: string; accent: string; accentText: string; accentSoft: string;
  good: string; goodSoft: string; warn: string; warnSoft: string; bad: string; badSoft: string; info: string; infoSoft: string;
}
const light: Theme = { bg: "#f6f7f9", surface: "#ffffff", surface2: "#f1f3f6", text: "#0f172a", muted: "#475569", line: "#d9dee6", accent: "#4338ca", accentText: "#ffffff", accentSoft: "#e8e9fb",
  good: "#166534", goodSoft: "#dcf5e4", warn: "#92400e", warnSoft: "#fdf0d2", bad: "#b91c1c", badSoft: "#fde4e4", info: "#1e40af", infoSoft: "#e0eafc" };
const dark: Theme = { bg: "#0b0f17", surface: "#121826", surface2: "#1a2233", text: "#e8ecf3", muted: "#a3aec2", line: "#29334a", accent: "#8b8cf8", accentText: "#0b0f17", accentSoft: "#232650",
  good: "#6ee7a0", goodSoft: "#12301f", warn: "#fbbf6a", warnSoft: "#382a10", bad: "#fca5a5", badSoft: "#3b1618", info: "#93b4fb", infoSoft: "#16264a" };

export function useTheme(pref: "system" | "light" | "dark" = "system"): Theme {
  const sys = useColorScheme();
  return (pref === "system" ? sys : pref) === "dark" ? dark : light;
}

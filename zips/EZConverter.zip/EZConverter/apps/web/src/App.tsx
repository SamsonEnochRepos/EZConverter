import { Icon, cx } from "@ezconverter/ui";
import { useEffect, useRef, useState } from "react";
import { type HistoryEntry, loadHistory, saveHistory, useApp } from "./state";
import { Convert } from "./views/Convert";
import { History } from "./views/History";
import { Settings } from "./views/Settings";

type View = "convert" | "history" | "settings";
const viewFromHash = (): View => (["history", "settings"].includes(location.hash.slice(2)) ? (location.hash.slice(2) as View) : "convert");

export function App() {
  const { state, catalog, controller } = useApp();
  const [view, setView] = useState<View>(viewFromHash);
  useEffect(() => { const f = () => setView(viewFromHash()); addEventListener("hashchange", f); return () => removeEventListener("hashchange", f); }, []);
  const go = (v: View) => { location.hash = v === "convert" ? "/" : `/${v}`; };

  // Record finished runs in local history exactly once.
  const recorded = useRef(new Set<string>());
  useEffect(() => {
    if (state.phase !== "finished") return;
    const fresh = state.runs.filter((r) => !recorded.current.has(r.batchId));
    if (!fresh.length) return;
    fresh.forEach((r) => recorded.current.add(r.batchId));
    void loadHistory().then((h) => {
      const entries: HistoryEntry[] = state.items.filter((i) => i.job && fresh.some((r) => r.jobKeys[i.job!.id] === i.key)).map((i) => ({
        id: i.job!.id, at: Date.now(), name: i.source.name, source: i.job!.source_format, target: i.job!.target_format, state: i.job!.state,
        size: i.result?.size, runtimeId: state.runs.find((r) => r.jobKeys[i.job!.id] === i.key)!.runtimeId, outputName: i.result?.name, error: i.job!.error?.message,
      }));
      return saveHistory([...entries, ...h]);
    });
  }, [state.phase, state.runs, state.items]);

  const offline = catalog.statuses.length > 0 && catalog.statuses.every((s) => s.state !== "online");
  const nav: [View, string, string][] = [["convert", "Convert", "arrow"], ["history", "History", "clock"], ["settings", "Settings", "settings"]];
  return (
    <div className="mx-auto flex min-h-dvh max-w-5xl flex-col px-4 pb-24 pt-4 sm:px-6">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-10 focus:rounded-lg focus:bg-surface focus:px-3 focus:py-2">Skip to content</a>
      <header className="flex items-center justify-between gap-4 py-3">
        <button type="button" className="flex min-h-11 items-center gap-2 text-lg font-bold tracking-tight" onClick={() => go("convert")} aria-label="EZConverter home">
          <span className="grid size-8 place-items-center rounded-lg bg-accent text-accentink"><Icon name="arrow" size={18} /></span>EZConverter
        </button>
        <nav aria-label="Main" className="flex gap-1">
          {nav.map(([v, label, icon]) => (
            <button key={v} type="button" onClick={() => go(v)} aria-current={view === v ? "page" : undefined}
                    className={cx("flex min-h-11 items-center gap-2 rounded-xl px-3 text-sm font-semibold", view === v ? "bg-accentsoft text-accent" : "text-muted hover:bg-surface2")}>
              <Icon name={icon} size={16} /><span className="hidden sm:inline">{label}</span><span className="sr-only sm:hidden">{label}</span>
            </button>
          ))}
        </nav>
      </header>
      {offline && view !== "settings" && (
        <div role="alert" className="mb-4 rounded-xl bg-warnsoft p-3 text-sm text-warn">
          No converter is reachable. Start the local converter or check the address in <button className="font-semibold underline" onClick={() => go("settings")}>Settings</button>.
        </div>
      )}
      <main id="main" className="flex-1" tabIndex={-1}>
        {view === "convert" && <Convert goSettings={() => go("settings")} />}
        {view === "history" && <History />}
        {view === "settings" && <Settings />}
      </main>
      <div aria-live="polite" className="sr-only" data-testid="live-region">
        {state.phase === "running" ? "Conversion in progress" : state.phase === "finished" ? "Conversion finished" : ""}
      </div>
      <footer className="mt-10 text-center text-xs text-muted">
        {controller && "Files are converted by the engines you configure and deleted automatically after the retention period."}
      </footer>
    </div>
  );
}

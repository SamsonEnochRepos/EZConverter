#!/usr/bin/env bash
# One-shot development setup: Python venv + editable backend, JS workspace, tool check.
set -euo pipefail
cd "$(dirname "$0")/.."

echo "==> Python environment"
python3 -m venv .venv
.venv/bin/pip install -q --upgrade pip
.venv/bin/pip install -q -e "backend[dev,sevenzip]" --config-settings editable_mode=compat

echo "==> JavaScript workspace"
command -v pnpm >/dev/null || { echo "pnpm is required (corepack enable && corepack prepare pnpm@10.28.0 --activate)"; exit 1; }
pnpm install

echo "==> External conversion tools"
missing=0
for t in ffmpeg ffprobe soffice pandoc pdftoppm pdfinfo prlimit unshare; do
  if command -v "$t" >/dev/null; then printf "  ok       %s\n" "$t"; else printf "  MISSING  %s (the capabilities that need it will not be advertised)\n" "$t"; missing=1; fi
done
[ "$missing" = 0 ] || echo "Install on Debian/Ubuntu: sudo apt-get install ffmpeg libreoffice-core libreoffice-writer libreoffice-calc libreoffice-impress libreoffice-draw pandoc poppler-utils util-linux"
echo "Done. Run scripts/verify.sh to execute every check."

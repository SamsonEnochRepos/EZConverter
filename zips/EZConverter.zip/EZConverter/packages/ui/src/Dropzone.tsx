import { useId, useRef, useState } from "react";
import { Icon, cx } from "./primitives";

export interface DropzoneProps {
  onFiles: (files: File[]) => void;
  disabled?: boolean;
  compact?: boolean;
  hint?: string;
}

/** Drag-and-drop target that is also a real, keyboard-operable file picker. */
export function Dropzone({ onFiles, disabled, compact, hint }: DropzoneProps) {
  const input = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  const id = useId();
  const take = (list: FileList | null) => { const files = list ? Array.from(list) : []; if (files.length && !disabled) onFiles(files); };
  return (
    <div
      onDragOver={(e) => { e.preventDefault(); if (!disabled) setOver(true); }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => { e.preventDefault(); setOver(false); take(e.dataTransfer.files); }}
      className={cx("rounded-card border-2 border-dashed text-center transition-colors", over ? "border-accent bg-accentsoft" : "border-line bg-surface",
                    compact ? "p-4" : "p-10 sm:p-14", disabled && "opacity-60")}
      data-testid="dropzone"
    >
      <input ref={input} id={id} data-testid="file-input" type="file" multiple className="sr-only" disabled={disabled}
             onChange={(e) => { take(e.target.files); e.target.value = ""; }} />
      <div className="mx-auto flex max-w-md flex-col items-center gap-3">
        <span className="grid size-12 place-items-center rounded-full bg-accentsoft text-accent"><Icon name="upload" size={24} /></span>
        <p className={cx("font-semibold", compact ? "text-sm" : "text-lg")}>{compact ? "Add more files" : "Drop files here to convert"}</p>
        {!compact && <p className="text-sm text-muted">{hint ?? "Documents, images, audio, video, archives and data files. Mix as many as you like."}</p>}
        <label htmlFor={id}
               className="inline-flex min-h-11 cursor-pointer items-center gap-2 rounded-xl bg-accent px-5 py-2.5 text-sm font-semibold text-accentink hover:opacity-90 focus-within:outline-2 has-[:focus-visible]:outline"
               tabIndex={disabled ? -1 : 0}
               onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); input.current?.click(); } }}>
          Choose files
        </label>
      </div>
    </div>
  );
}
